//Singly Connected Component and Topological sort for Directed graph

#include<bits/stdc++.h>
using namespace std;

#define White 0
#define Grey 1
#define Black 2
#define inf 1/0.0

int a,b,i,vertex,edge,d[100],f[100],color[100],colorT[100],t,pre[100],SCC;


vector<int>topo;
list<int>adj[100],graphT[100];
void dfs(int node)
{
    list<int>::iterator it;

    d[node] = ++t;
    color[node] = Grey;

    for(it=adj[node].begin();it!=adj[node].end();it++)
    {
        int v = *it;
            if(color[v] == White){
                color[v] = Grey;
                pre[v] = node;
                dfs(v);
                // printf("%d-",i);
            }
    }
    topo.insert(topo.begin(),node);

    color[node] = Black;
    f[node] = ++t; 

}

void dfsT(int node, bool scc)
{
    list<int>::iterator it;

    colorT[node] = Grey;
    if(!scc) cout << node << " " ;
    for(it=graphT[node].begin();it!=graphT[node].end();it++)
    {
        int v = *it;
            if(colorT[v] == White){
                dfsT(v,false);
                // printf("%d-",i);
            }
    }

    colorT[node] = Black;

}

void  transpose()
{
    list<int>::iterator it;

    for(int i=1;i<=vertex;i++)
        for( it=adj[i].begin();it!=adj[i].end();it++)
                graphT[*it].push_back(i);

}

int main()
{
    freopen("data.txt","r",stdin);
    memset(pre,-1,sizeof(pre));
    memset(d,inf,sizeof(pre));
    memset(f,inf,sizeof(pre));
    
    cout << "Input Number of vertex: " ;
    cin >> vertex;

    while(1)
    {
        cout << "Edge " << i+1 << ": " ;

        cin >> a >> b;
        if(a==0 || b==0) break;
        if(a>vertex || b > vertex)
            cout << "Invalid Input" << endl;

        else{
            adj[a].push_back(b);
            // adj[b][a] = 1;
            i++;
        }
    }
    cout << endl<< endl ;

    transpose();

    // for(int i=1;i<=vertex;i++)
    // {
    //     for(int j = 0 ; j<graphT[i].size();j++)
    //         cout <<  graphT[i][j] << " ";
    //     cout << endl;

    // }


    for(int i=1;i<=vertex;i++)
        if(color[i]==White)
            dfs(i);

    for(int i=0;i<topo.size();i++)
        if(colorT[topo[i]] == White)
        {
            cout << topo[i] << ": " ;
            dfsT(topo[i],true);
            cout << endl;
            SCC++;
        }

    cout << "\nTotal SCC: " << SCC <<endl;

    // for(int i =1;i<=vertex;i++)
    //     cout << "Discovering and finishing time of node " << i 
    //         << "---> " << d[i] << "/" << f[i] << endl ;

    cout << "\nTopological Sort: ";
    for(int i = 0; i<topo.size();i++)
        cout << topo[i] << " ";
    cout << endl << endl;



    return 0;
}